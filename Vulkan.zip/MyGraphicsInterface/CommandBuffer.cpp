
#include"VulkanApplication.h"
#include"CommandBuffer.h"


//void CommandBuffer::SetViewport(Rect viewport) {
//
//}
//void CommandBuffer::Draw(Mesh mesh, Material material, int submesh) {
//	
//
//}